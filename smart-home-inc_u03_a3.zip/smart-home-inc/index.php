<!DOCTYPE html>
<html lang="en">

<head>


  <link rel="stylesheet" href="/smart-home-inc/assets/css/index.css" />
  <link rel="stylesheet" href="/smart-home-inc/assets/css/bootstrap.min.css" />


  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Smart Homes, Inc.</title>
</head>

<body>
  <?php include './components/nav.php'; ?>

  <div class="container">

    <h1>Welcome to Smart Homes, Inc.</h1>

    


    <script src="/smart-home-inc/assets/js/bootstrap.min.js"></script>

  </div>

</body>

</html>