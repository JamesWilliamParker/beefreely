<?php
echo '<nav class="navbar navbar-expand-lg navbar-light bg-light">';
echo '<div class="container">';
echo '<a class="navbar-brand" href="/smart-home-inc/index.php">Home</a>';
echo '<a class="navbar-brand" href="/smart-home-inc/store-locator.php">Store Locator</a>';
echo '<a class="navbar-brand" href="/smart-home-inc/social.php">Social</a>';
echo '</div>';
echo '</nav>';
